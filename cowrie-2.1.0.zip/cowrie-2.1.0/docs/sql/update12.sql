ALTER TABLE `downloads` MODIFY `outfile` text default NULL;
