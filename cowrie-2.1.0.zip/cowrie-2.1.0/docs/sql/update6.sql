/* Remove an unnecessary feature */
ALTER TABLE `sessions` DROP `termtitle` ;
