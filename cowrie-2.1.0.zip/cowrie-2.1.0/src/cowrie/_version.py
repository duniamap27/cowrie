"""
Provides cowrie version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update cowrie` to change this file.

from incremental import Version

__version__ = Version('cowrie', 2, 0, 2)
__all__ = ["__version__"]
